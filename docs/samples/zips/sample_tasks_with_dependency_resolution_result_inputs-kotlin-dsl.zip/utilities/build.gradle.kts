plugins {
    id("java-library")
}

dependencies {
    api(project(":list"))
}
