
plugins {
    `cpp-library` // <1>

    `cpp-unit-test` // <2>
}

library {
    targetMachines.add(machines.macOS.architecture("aarch64")) // <3>
}
