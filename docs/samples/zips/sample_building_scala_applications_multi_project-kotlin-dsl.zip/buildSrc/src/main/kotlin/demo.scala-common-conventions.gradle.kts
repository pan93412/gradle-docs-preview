
plugins {
    scala // <1>
}

repositories {
    mavenCentral() // <2>
}

dependencies {
    constraints {
        implementation("org.apache.commons:commons-text:1.10.0") // <3>

        implementation("org.scala-lang:scala-library:2.13.10")
    }

    implementation("org.scala-lang:scala-library") // <4>

    testImplementation("org.junit.jupiter:junit-jupiter:5.9.1") // <5>
}

tasks.named<Test>("test") {
    useJUnitPlatform() // <6>
}
