
plugins {
    groovy // <1>

    `java-library` // <2>
}

repositories {
    mavenCentral() // <3>
}

dependencies {
    implementation("org.codehaus.groovy:groovy-all:3.0.13") // <4>

    implementation("com.google.guava:guava:31.1-jre") // <5>

    testImplementation("org.spockframework:spock-core:2.2-groovy-3.0") // <6>
    testImplementation("junit:junit:4.13.2")

    api("org.apache.commons:commons-math3:3.6.1") // <7>
}

tasks.named<Test>("test") {
    useJUnitPlatform() // <8>
}
