
plugins {
    id("demo.groovy-library-conventions")
}
