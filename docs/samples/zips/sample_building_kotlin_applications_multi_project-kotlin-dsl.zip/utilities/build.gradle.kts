
plugins {
    id("demo.kotlin-library-conventions")
}

dependencies {
    api(project(":list"))
}
