
plugins {
    id("demo.java-common-conventions") // <1>

    application // <2>
}
