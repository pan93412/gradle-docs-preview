
plugins {
    scala // <1>

    application // <2>
}

repositories {
    mavenCentral() // <3>
}

dependencies {
    implementation("org.scala-lang:scala-library:2.13.10") // <4>

    implementation("com.google.guava:guava:31.1-jre") // <5>

    testImplementation("junit:junit:4.13.2") // <6>
    testImplementation("org.scalatest:scalatest_2.13:3.2.14")
    testImplementation("org.scalatestplus:junit-4-13_2.13:3.2.2.0")

    testRuntimeOnly("org.scala-lang.modules:scala-xml_2.13:1.2.0") // <7>
}

application {
    mainClass.set("demo.App") // <8>
}
