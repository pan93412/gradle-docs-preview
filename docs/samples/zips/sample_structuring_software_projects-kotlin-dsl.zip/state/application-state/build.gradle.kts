plugins {
    id("com.example.kotlin-library")
}

group = "${group}.state"
