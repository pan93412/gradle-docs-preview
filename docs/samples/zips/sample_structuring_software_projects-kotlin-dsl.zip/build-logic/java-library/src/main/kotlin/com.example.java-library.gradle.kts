plugins {
    id("com.example.commons")
    id("java-library")
}
