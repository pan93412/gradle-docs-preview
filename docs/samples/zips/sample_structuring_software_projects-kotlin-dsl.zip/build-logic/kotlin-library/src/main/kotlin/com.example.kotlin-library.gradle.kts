plugins {
    id("com.example.commons")
    id("org.jetbrains.kotlin.jvm")
    id("java-library")
}

dependencies {
    implementation(kotlin("stdlib"))
}
