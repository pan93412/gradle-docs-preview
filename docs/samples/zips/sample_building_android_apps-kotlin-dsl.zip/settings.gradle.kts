pluginManagement {
    repositories {
        gradlePluginPortal()
        google()
    }
}

rootProject.name = "my-app"

include(":app")
