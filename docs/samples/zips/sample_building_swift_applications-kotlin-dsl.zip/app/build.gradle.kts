
plugins {
    `swift-application` // <1>

    xctest // <2>
}

application { // <3>
    targetMachines.add(machines.macOS.architecture("aarch64")) // <4>
}
