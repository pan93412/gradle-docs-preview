rootProject.name = "task-with-arguments"
includeBuild("project-info")
